<?php

/**
 * @package     Joomla.Administrator
 * @subpackage  com_awinsignupform
 *
 * @copyright   Copyright (C) 2020 Adam Winther. All rights reserved.
 * @license     GNU General Public License version 3; see LICENSE
 */

 // No direct access to this file
defined('_JEXEC') or die('Restricted Access');
?>
<h2>This is my Awin Signup Form in Backend side!</h2>